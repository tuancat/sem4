/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.sam.booklibrary.configuration;

/**
 *
 * @author cattuan
 */
public class Constants {

    public static final String MODULE_STRING = "module";
    public static final String FUNCTION_STRING = "function";

    public static final String FUNCTION_LISTBOOKS_STRING = "ListBookServlet";
    public static final String FUNCTION_LISTUSER_STRING = "ListUserServlet";
    public static final String FUNCTION_BOOK_STRING = "BorrowBookServlet";

}
